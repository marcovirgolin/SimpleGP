=========
Simple GP
=========

A simple implementation of genetic programming for symbolic regression.

